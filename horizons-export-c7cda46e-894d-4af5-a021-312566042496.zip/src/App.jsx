
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Home from '@/pages/Home';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Booking from '@/pages/Booking';
import Documents from '@/pages/Documents';
import Contact from '@/pages/Contact';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import Faq from '@/pages/Faq';
import ServiceArea from '@/pages/ServiceArea';
import Testimonials from '@/pages/Testimonials';
import ScrollToTop from '@/components/ScrollToTop';
import Chatbot from '@/components/Chatbot';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/online-booking" element={<Booking />} />
            <Route path="/tax-documents" element={<Documents />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/faq" element={<Faq />} />
            <Route path="/service-area" element={<ServiceArea />} />
            <Route path="/testimonials" element={<Testimonials />} />
          </Routes>
        </main>
        <Footer />
        <Toaster />
        <Chatbot />
      </div>
    </Router>
  );
}

export default App;
