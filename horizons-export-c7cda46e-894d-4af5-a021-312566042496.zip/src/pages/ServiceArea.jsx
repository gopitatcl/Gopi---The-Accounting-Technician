import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, CheckCircle, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const ServiceArea = () => {
  const fraserValleyCities = [
    "Abbotsford",
    "Mission",
    "Chilliwack",
    "Langley",
    "Maple Ridge",
    "Pitt Meadows",
    "Surrey",
    "Vancouver"
  ];

  return (
    <>
      <Helmet>
        <title>Service Area | Abbotsford, Fraser Valley &amp; BC Accountant | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="Gopi The Accounting Technician Ltd provides bookkeeping and tax services to Abbotsford, Mission, Chilliwack, Langley, and offers virtual accounting across B.C." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">Our Service Area</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Proudly providing bookkeeping and tax services to Abbotsford, the Fraser Valley, Vancouver, and surrounding communities.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Local B.C. Accountant</h2>
                <p className="text-lg text-gray-600 mb-6">
                  While our office is based in <strong>Abbotsford, B.C.</strong>, our commitment to providing exceptional financial services extends throughout the beautiful Fraser Valley and into Vancouver. We understand the local economy and the unique challenges and opportunities for small businesses in this region.
                </p>
                <p className="text-lg text-gray-600 mb-8">
                  Whether you need a <strong>small business accountant in Abbotsford</strong>, a bookkeeper in Surrey, or tax preparation services in Vancouver, Gopi - The Accounting Technician Ltd. is here to help.
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">We proudly serve:</h3>
                <div className="grid grid-cols-2 gap-4">
                  {fraserValleyCities.map(city => (
                    <div key={city} className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-gray-700">{city}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="rounded-lg overflow-hidden shadow-2xl"
              >
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=-123.2,49.0,-121.5,49.3&layer=mapnik"
                    className="w-full h-full border-0"
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Map of Fraser Valley and Vancouver Service Area"
                  ></iframe>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-lg"
            >
              <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Serving Clients Across Canada</h2>
              <p className="text-lg text-gray-600 mb-6">
                In addition to our local focus, Gopi - The Accounting Technician Ltd. is fully equipped to provide virtual accounting services to clients anywhere in Canada, ensuring you get expert financial support no matter where you are located.
              </p>
              <Link to="/contact">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  Contact Us For a Consultation
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ServiceArea;