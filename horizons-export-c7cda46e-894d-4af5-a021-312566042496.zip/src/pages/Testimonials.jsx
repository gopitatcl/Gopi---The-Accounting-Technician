import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const Testimonials = () => {
  const navigate = useNavigate();

  const handleBookConsultation = () => {
    navigate('/online-booking');
  };

  const testimonials = [
    {
      name: "Gurvinder Khabra",
      time: "6 months ago",
      rating: 5,
      review: "Excellent Accounting & Financial Services! I highly recommend Gopi - The Accounting Technician Ltd for their exceptional accounting services. Gopinath Nayak helped me recover old debts and streamline multiple years of accounts, making my financial records clear and organized. His expertise, professionalism, and dedication made a complex process smooth and stress-free. If you're looking for a reliable accountant who truly cares about your business, look no further!",
      isLocalGuide: false,
    },
    {
      name: "Piyushsinh Rajput",
      time: "5 months ago",
      rating: 5,
      review: "Fast, efficient, and stress-free tax filing! Gopinath handled everything professionally and explained all the details clearly. Will definitely return next year!",
      isLocalGuide: false,
    },
    {
      name: "Shaurya Sharma",
      time: "3 months ago",
      rating: 5,
      review: "Gopi was very helpful with my taxes, very professional and knowledgeable, great service, easy 5 stars 👍.",
      isLocalGuide: false,
    },
    {
      name: "Mohsin Raza",
      time: "1 year ago",
      rating: 5,
      review: "Great service. Always available to help. Filed our business taxes on time. Highly recommend.",
      isLocalGuide: true,
    },
  ];

  return (
    <>
      <Helmet>
        <title>Client Testimonials | Gopi The Accounting Technician Ltd – Abbotsford Reviews</title>
        <meta name="description" content="See what local businesses in Abbotsford and the Fraser Valley are saying about our expert bookkeeping, accounting, and tax services from Gopi The Accounting Technician Ltd." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">What Our Clients Say</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Real reviews from satisfied clients in Abbotsford and the Fraser Valley for Gopi - The Accounting Technician Ltd.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full flex flex-col shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-xl font-bold text-gray-600">{testimonial.name.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{testimonial.name}</p>
                          {testimonial.isLocalGuide && <p className="text-sm text-gray-500">Local Guide</p>}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow flex flex-col">
                      <div className="flex items-center space-x-1 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                        ))}
                        <p className="text-sm text-gray-500 ml-2">{testimonial.time}</p>
                      </div>
                      <p className="text-gray-700">"{testimonial.review}"</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Be Our Next Success Story?
              </h2>
              <Button
                onClick={handleBookConsultation}
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                Book Your Free Consultation
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Testimonials;