import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useParams, Link } from 'react-router-dom';
import blogPosts from '@/data/blogPosts.js';
import { ArrowLeft, Calendar, User, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="flex items-center justify-center h-screen text-center px-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">404 - Post Not Found</h1>
          <p className="mt-4 text-lg">Sorry, we couldn't find the blog post you're looking for.</p>
          <Link to="/blog">
            <Button className="mt-8">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Gopi The Accounting Technician Ltd.</title>
        <meta name="description" content={post.metaDescription || post.summary} />
        {post.keywords && <meta name="keywords" content={post.keywords} />}
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"
          >
            <div className="flex items-center space-x-2 text-sm text-yellow-400">
              <Tag className="h-4 w-4" />
              <span>{post.category}</span>
            </div>
            <h1 className="mt-2 text-3xl md:text-5xl font-bold">{post.title}</h1>
            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-blue-100">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>{new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="aspect-w-16 aspect-h-9 mb-12">
                <img 
                  className="rounded-lg object-cover w-full h-full shadow-2xl"
                  alt={post.title}
                 src={post.image} loading="lazy" />
              </div>
              <div
                className="prose lg:prose-xl max-w-none text-gray-700"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />
              <div className="mt-12 border-t pt-8">
                <Link to="/blog">
                  <Button variant="outline">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Posts
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default BlogPost;