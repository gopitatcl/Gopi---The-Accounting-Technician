import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { User, Briefcase, Building, CheckSquare, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

const Documents = () => {
  const navigate = useNavigate();

  const handleContact = () => {
    navigate('/contact');
  };

  const documentLists = {
    individuals: [
      "T4 slips from all employers",
      "RRSP contribution receipts",
      "Charitable donation receipts",
      "Medical expense receipts",
      "T2202 for tuition and education",
      "Notice of Assessment from previous year",
    ],
    selfEmployed: [
      "Income statements (e.g., invoices, sales records)",
      "All business expense receipts",
      "GST/HST returns and payment records",
      "Vehicle logbook with mileage details",
      "Home office expense details",
      "Bank and credit card statements",
    ],
    corporations: [
      "Complete financial statements (Balance Sheet, Income Statement)",
      "Business bank and credit card statements",
      "Payroll summaries and T4s issued",
      "Prior year corporate tax returns (T2)",
      "Details of asset additions or disposals",
      "Shareholder loan account details",
    ],
  };

  const sections = [
    {
      icon: <User className="h-8 w-8 text-white" />,
      title: "Individuals",
      list: documentLists.individuals
    },
    {
      icon: <Briefcase className="h-8 w-8 text-white" />,
      title: "Self-Employed",
      list: documentLists.selfEmployed
    },
    {
      icon: <Building className="h-8 w-8 text-white" />,
      title: "Corporations",
      list: documentLists.corporations
    }
  ];

  return (
    <>
      <Helmet>
        <title>Tax Filing Document Checklist | Self-Employed Tax Help BC | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="A checklist of required documents for individual, self-employed, and corporate tax filing. Get self-employed tax help in BC from our Abbotsford accounting firm." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">Required Tax Filing Documents</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Be prepared for tax season with Gopi - The Accounting Technician Ltd. Here's a checklist of documents you'll need.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {sections.map((section, index) => (
                <motion.div
                  key={section.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full shadow-lg hover:shadow-2xl transition-shadow duration-300">
                    <CardHeader className="text-center">
                       <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-xl flex items-center justify-center mb-4 shadow-lg mx-auto">
                        {section.icon}
                      </div>
                      <CardTitle className="text-2xl">{section.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {section.list.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start">
                            <CheckSquare className="h-5 w-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
              className="mt-16 text-center bg-blue-100 p-8 rounded-2xl"
            >
              <FileText className="h-10 w-10 text-blue-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Need help preparing your documents?</h3>
              <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
                Gathering everything can be overwhelming. Gopi - The Accounting Technician Ltd. is here to provide guidance and ensure you have everything you need for a smooth tax filing process.
              </p>
              <Button onClick={handleContact} size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                Contact Us for Guidance
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Documents;