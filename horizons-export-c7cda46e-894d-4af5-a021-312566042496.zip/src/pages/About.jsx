import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { 
  CheckCircle,
  Calendar,
  Eye,
  Heart,
  Star,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const About = () => {
  const navigate = useNavigate();

  const handleBookConsultation = () => {
    navigate('/online-booking');
  };

  const values = [
    {
      icon: <CheckCircle className="h-6 w-6" />,
      title: "Precision",
      description: "We guarantee precision in every calculation, ensuring your books are always accurate."
    },
    {
      icon: <Eye className="h-6 w-6" />,
      title: "Clarity",
      description: "We turn numbers into clear insights, providing transparent and straightforward financial guidance."
    },
    {
      icon: <Heart className="h-6 w-6" />,
      title: "Care",
      description: "Your success is our priority. We offer personalized, client-centered service with genuine care."
    }
  ];

  const testimonials = [
    {
      name: "Shaurya Sharma",
      time: "3 months ago",
      rating: 5,
      review: "Gopi was very helpful with my taxes, very professional and knowledgeable, great service, easy 5 stars 👍.",
      isLocalGuide: false,
    },
    {
      name: "Mohsin Raza",
      time: "1 year ago",
      rating: 5,
      review: "Great service. Always available to help. Filed our business taxes on time. Highly recommend.",
      isLocalGuide: true,
    },
  ];
  
  return (
    <>
      <Helmet>
        <title>About Our Firm | Abbotsford Accountant &amp; Bookkeeper | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="Learn about Gopi The Accounting Technician Ltd, a CPB Canada-certified accounting firm in Abbotsford, BC. We offer expert bookkeeping, tax filing, and CRA audit support." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-20"></div>
          <div className="absolute inset-0">
            <div className="absolute top-10 left-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
            <div className="absolute bottom-10 right-10 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-8"
              >
                <div className="space-y-4">
                  <h2 className="text-xl md:text-2xl font-bold text-white tracking-wide">Gopi - The Accounting Technician Ltd.</h2>
                  <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                    Your Trusted Abbotsford Accountant & Bookkeeper
                  </h1>
                  <p className="text-lg md:text-xl text-blue-100 max-w-2xl">
                    With over 25 years of experience, Gopi - The Accounting Technician Ltd. turns numbers into clarity for small businesses and individuals.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative"
              >
                <div className="relative z-10">
                  <img  
                    className="rounded-2xl shadow-2xl w-full max-w-lg mx-auto hover-lift"
                    alt="Gopinath Nayak, founder of Gopi - The Accounting Technician Ltd." src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/c47727b584e6b587f6d5fc6bfcced30a.jpg" loading="lazy" />
                </div>
                <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-br from-yellow-400 to-orange-400 rounded-2xl opacity-20 blur-lg"></div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-8 text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Precision, Clarity, and Care</h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                With over 25 years of experience, Gopi The Accounting Technician Ltd. offers bookkeeping, accounting, and tax services with precision and care. As a Certified Professional Bookkeeper (CPB Canada) and QuickBooks Advanced Online ProAdvisor, we turn numbers into clarity for small businesses and individuals in Abbotsford and the Fraser Valley.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Founded by Gopinath Nayak, our firm is built on a foundation of trust, expertise, and a genuine desire to help local businesses succeed. We understand the challenges of entrepreneurship and are committed to providing the financial tools and insights you need to thrive.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12 md:mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Core Values</h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                These principles guide every service we provide.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center group p-6"
                >
                  <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-full flex items-center justify-center text-white mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
        
        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12 md:mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Our Certifications
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Your assurance of professional, high-quality accounting services in Abbotsford.
              </p>
            </motion.div>

            <div className="flex flex-wrap gap-8 justify-center items-center">
               <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                   viewport={{ once: true }}
                  className="w-40 h-40 bg-white rounded-lg flex items-center justify-center p-4 shadow-lg hover:scale-105 transition-transform"
                >
                  <img
                    loading="lazy"
                    src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/ea2371cba95697d801d8c5b991ede8ac.png"
                    alt="CPB Canada certification logo for Abbotsford bookkeeper"
                    className="max-w-full max-h-full object-contain"
                  />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                   viewport={{ once: true }}
                  className="w-40 h-40 bg-white rounded-lg flex items-center justify-center p-4 shadow-lg hover:scale-105 transition-transform"
                >
                  <img
                    loading="lazy"
                    src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/ea3572f7ee7ebdbeec8eeca13c34c129.png"
                    alt="QuickBooks ProAdvisor logo for accounting services BC"
                    className="max-w-full max-h-full object-contain"
                  />
                </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 md:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">We're proud to be a trusted partner for businesses in Abbotsford.</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full flex flex-col shadow-lg">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-xl font-bold text-gray-600">{testimonial.name.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{testimonial.name}</p>
                          {testimonial.isLocalGuide && <p className="text-sm text-gray-500">Local Guide</p>}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow flex flex-col">
                      <div className="flex items-center space-x-1 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                        ))}
                        <p className="text-sm text-gray-500 ml-2">{testimonial.time}</p>
                      </div>
                      <p className="text-gray-700 italic flex-grow">"{testimonial.review}"</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            <div className="text-center mt-12">
              <Button onClick={() => navigate('/testimonials')} variant="outline">
                View More Testimonials <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Work Together?
              </h2>
              <p className="text-lg md:text-xl text-blue-100 max-w-2xl mx-auto">
                Contact Gopi - The Accounting Technician Ltd. for a free consultation and let's bring clarity to your finances.
              </p>
              <Button 
                onClick={handleBookConsultation}
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                Book a Free Consultation
                <Calendar className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;