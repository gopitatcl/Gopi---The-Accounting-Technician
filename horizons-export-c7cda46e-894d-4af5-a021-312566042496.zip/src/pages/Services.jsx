
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import {
  Book,
  FileText,
  Users,
  Briefcase,
  CheckCircle,
  Clock,
  MapPin,
  Globe,
  BarChart2,
  TrendingUp,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const Services = () => {
  const navigate = useNavigate();

  const handleBookConsultation = () => {
    navigate('/online-booking');
  };

  const servicesList = [
    {
      icon: <Book className="h-8 w-8" />,
      title: "Bookkeeping Services",
      description: "Keep your business finances accurate and organized with our expert bookkeeping services. We ensure your records are always up-to-date and compliant.",
      includes: ["Daily/monthly bookkeeping", "Bank & credit card reconciliations", "Financial statement preparation", "GST/HST returns"],
    },
    {
      icon: <FileText className="h-8 w-8" />,
      title: "Accounting & Tax Services",
      description: "Navigate tax season with confidence. We provide comprehensive personal and corporate tax filing to maximize your returns and minimize stress.",
      includes: [
        "Personal tax filing (T1)", 
        "Corporate tax filing (T2)",
        "GST/HST, WCB & PST filing",
        "Tax slips (T4, T5, T5018)",
        "Year-end financial statements", 
        "CRA compliance & correspondence"
      ],
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Payroll Services",
      description: "Streamline your payroll with our reliable services. We manage everything from pay processing to year-end tax slips, ensuring your employees are paid correctly and on time.",
      includes: ["Payroll processing", "Source deduction remittances", "T4 & T5 slip filing", "Record of Employment (ROE)"],
    },
    {
      icon: <Briefcase className="h-8 w-8" />,
      title: "Business Registration & Advisory",
      description: "Start or grow your business on a solid foundation. We offer expert guidance on business setup, registration, and strategic financial planning.",
      includes: ["Business setup assistance", "Sole proprietorship & incorporation", "Strategic financial planning", "Cash flow management"],
    },
    {
      icon: <BarChart2 className="h-8 w-8" />,
      title: "Financial Reporting & Analysis",
      description: "Gain clear financial insights to help grow your business. We prepare meaningful reports so you can track performance, manage cash flow, and make smarter decisions.",
      includes: [
        "Monthly & quarterly financial reports",
        "Budget vs actual analysis",
        "Cash flow statements",
        "Profit & loss analysis"
      ],
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: "Business Tax Planning",
      description: "Pay less tax and plan for the future. We work with you year-round to help reduce tax liability, avoid penalties, and grow with confidence.",
      includes: [
        "Small business tax strategy",
        "Year-end planning",
        "Expense optimization",
        "Owner compensation planning"
      ],
    },
  ];

  const whyChooseUs = [
    "CPB Canada Certified",
    "QuickBooks Advanced ProAdvisor",
    "Personalized, one-on-one service",
    "Focus on Abbotsford small businesses",
    "Commitment to accuracy and clarity",
  ];
  
  const fraserValleyCities = [
    "Abbotsford",
    "Mission",
    "Chilliwack",
    "Langley",
    "Maple Ridge",
    "Pitt Meadows",
    "Surrey",
    "Vancouver"
  ];

  return (
    <>
      <Helmet>
        <title>Accounting & Bookkeeping Services in Abbotsford | Gopi The Accounting Technician Ltd</title>
        <meta 
          name="description" 
          content="Professional bookkeeping, tax filing, payroll, and business advisory services in Abbotsford & Fraser Valley. CPB Canada-certified accounting firm trusted by local businesses." 
        />
        <link rel="canonical" href="https://www.gopiaccountant.com/services" />
        <meta property="og:title" content="Accounting & Bookkeeping Services in Abbotsford" />
        <meta property="og:description" content="Expert bookkeeping, tax filing, payroll & business advisory services for Abbotsford small businesses. Free consultation available." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.gopiaccountant.com/services" />
        <meta property="og:image" content="https://www.gopiaccountant.com/og-services.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Abbotsford Bookkeeping & Tax Services" />
        <meta name="twitter:description" content="Bookkeeping, tax filing & payroll services for small businesses in Abbotsford and Fraser Valley. Free consultation available." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-20"></div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">Our Services</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Comprehensive accounting and bookkeeping solutions for your Abbotsford business from Gopi - The Accounting Technician Ltd.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 md:mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How We Can Help</h2>
                <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                    Gopi - The Accounting Technician Ltd. provides the financial clarity you need to grow your business with confidence.
                </p>
            </div>
            <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-8">
              {servicesList.map((service, index) => (
                 <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Accordion type="single" collapsible className="w-full bg-white p-6 rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300">
                    <AccordionItem value={`item-${index}`}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center space-x-4 text-left">
                          <div className="flex-shrink-0 bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-xl flex items-center justify-center text-white shadow-lg">
                            {service.icon}
                          </div>
                          <h3 className="text-xl font-bold text-gray-900">{service.title}</h3>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-6">
                        <p className="text-gray-600 mb-6">{service.description}</p>
                        {service.includes && (
                          <>
                            <h4 className="font-semibold text-gray-800 mb-2">Key services include:</h4>
                            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 list-inside mb-4">
                              {service.includes.map(item => (
                                <li key={item} className="flex items-start">
                                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                                  <span className="text-gray-600">{item}</span>
                                </li>
                              ))}
                            </ul>
                          </>
                        )}
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="text-3xl font-bold text-gray-900 text-center">Why Partner with Us?</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                    {whyChooseUs.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-6 w-6 text-blue-600 mr-3 mt-1 flex-shrink-0" />
                        <span className="text-lg text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
        
        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 md:mb-16">
              <MapPin className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Service Area</h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Gopi - The Accounting Technician Ltd. proudly serves Abbotsford, the Fraser Valley, and clients across Canada.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12 items-center">
               <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-lg shadow-lg"
              >
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Local Service in the Fraser Valley</h3>
                <p className="text-gray-600 mb-6">
                  We offer dedicated accounting and bookkeeping services to businesses in:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
                  {fraserValleyCities.map(city => (
                    <div key={city} className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-gray-700">{city}</span>
                    </div>
                  ))}
                </div>
                 <Link to="/service-area">
                    <Button variant="outline">
                        Learn More About Our Reach
                    </Button>
                </Link>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-lg shadow-lg"
              >
                <Globe className="h-10 w-10 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Virtual Services Across Canada</h3>
                 <p className="text-gray-600 mb-6">
                   Not in the Fraser Valley? No problem. Gopi - The Accounting Technician Ltd. provides secure and efficient virtual accounting services to clients anywhere in Canada, ensuring you get expert financial support no matter your location.
                </p>
                <Link to="/contact">
                  <Button variant="outline">
                    Inquire About Virtual Services
                  </Button>
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Let's Discuss Your Needs
              </h2>
              <p className="text-lg md:text-xl text-blue-100 max-w-2xl mx-auto">
                Schedule a free, no-obligation consultation with Gopi - The Accounting Technician Ltd. to discover how our services can benefit your business.
              </p>
              <Button 
                onClick={handleBookConsultation}
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                Book a Free Consultation
                <Clock className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Services;
