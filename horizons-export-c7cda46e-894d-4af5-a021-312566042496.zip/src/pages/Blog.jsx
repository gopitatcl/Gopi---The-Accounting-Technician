import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import blogPosts from '@/data/blogPosts.js';
import { ArrowRight, Tag } from 'lucide-react';

const Blog = () => {
  const categories = ['All', 'Tax Tips', 'Payroll', 'Bookkeeping Basics'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredPosts = activeCategory === 'All'
    ? blogPosts
    : blogPosts.filter(post => post.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Accounting Blog &amp; Tax Tips | Abbotsford, BC | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="Read the latest insights on bookkeeping, CRA audit support, and small business tax tips from our Abbotsford-based accounting experts." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">Insights & Resources</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Your source for expert advice on accounting and bookkeeping from Gopi - The Accounting Technician Ltd. in Abbotsford.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-12">
              {categories.map(category => (
                <Button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  variant={activeCategory === category ? 'default' : 'outline'}
                  className={`rounded-full transition-all duration-300 ${activeCategory === category ? 'bg-blue-600 text-white' : 'bg-white'}`}
                >
                  {category}
                </Button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full flex flex-col shadow-lg hover:shadow-2xl transition-shadow duration-300">
                    <CardHeader>
                      <div className="aspect-w-16 aspect-h-9 mb-4">
                        <img 
                          className="rounded-t-lg object-cover w-full h-48"
                          alt={post.title}
                         src={post.image} loading="lazy" />
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-blue-600">
                        <Tag className="h-4 w-4" />
                        <span>{post.category}</span>
                      </div>
                      <CardTitle className="text-xl pt-2">{post.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <p className="text-gray-600">{post.summary}</p>
                    </CardContent>
                    <CardFooter>
                      <Link to={`/blog/${post.slug}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          Read More <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Blog;