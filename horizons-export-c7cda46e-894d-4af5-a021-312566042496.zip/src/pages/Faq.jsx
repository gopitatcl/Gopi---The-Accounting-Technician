import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Mail, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Faq = () => {
  const faqItems = [
    {
      question: "What are your rates for bookkeeping services for a small business in Abbotsford?",
      answer: "Our rates for bookkeeping services are tailored to the specific needs and transaction volume of your small business. We offer monthly packages to ensure predictable costs. For a precise quote based on your requirements, please contact us for a free consultation. We are committed to providing affordable and transparent pricing for all Abbotsford businesses."
    },
    {
      question: "What documents do I need for tax filing in B.C.?",
      answer: "For personal tax filing in B.C., you'll typically need all T-slips (T4, T4A, T5, etc.), receipts for deductions (RRSP contributions, medical expenses, charitable donations), and any information on other income. For businesses, you'll need a summary of your income and expenses. We have a detailed checklist on our 'Tax Documents' page to help you prepare for your tax preparation in Abbotsford B.C."
    },
    {
      question: "How can Gopi - The Accounting Technician Ltd help my business save money on taxes?",
      answer: "As your dedicated small business accountant in Abbotsford, we go beyond simple tax filing. We proactively identify all eligible deductions and tax credits your business is entitled to. Through strategic tax planning and expert financial consulting, we help structure your finances to minimize your tax liability and improve your bottom line."
    },
    {
      question: "Do you offer payroll services for Abbotsford businesses?",
      answer: "Yes, we offer comprehensive payroll services in Abbotsford. Our services include calculating pay and deductions, remitting to the CRA, and issuing pay stubs and T4s. We ensure your payroll is accurate, compliant, and on time, so you can focus on running your business."
    },
    {
      question: "I'm just starting my business. Can you help with business registration?",
      answer: "Absolutely! We provide support for business registration to help you start your new venture on the right foot. We can guide you through the process of choosing the right business structure (sole proprietorship, partnership, or corporation) and ensure all necessary paperwork is filed correctly."
    },
    {
      question: "What areas do you serve besides Abbotsford?",
      answer: "While we are proud to be an Abbotsford accountant, our service area extends throughout the Fraser Valley, including Mission, Chilliwack, and Langley. We also offer full virtual accounting and bookkeeping services to clients across British Columbia and Canada."
    }
  ];

  return (
    <>
      <Helmet>
        <title>FAQ | Bookkeeping &amp; Tax Questions | Abbotsford Accountant</title>
        <meta name="description" content="Find answers to common questions about bookkeeping, tax services, and CRA audit support for Abbotsford businesses from Gopi The Accounting Technician Ltd." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold">Frequently Asked Questions</h1>
            <p className="mt-4 text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">
              Answers to common questions about our bookkeeping and tax filing services from Gopi - The Accounting Technician Ltd. in Abbotsford.
            </p>
          </motion.div>
        </section>

        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Accordion type="single" collapsible className="w-full space-y-4">
                {faqItems.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg shadow-md px-6">
                    <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 text-base pt-2">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="mt-16 text-center bg-white p-8 rounded-lg shadow-lg"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Still have questions?</h2>
              <p className="text-lg text-gray-600 mb-6">
                If you can't find the answer you're looking for, please don't hesitate to get in touch with Gopi - The Accounting Technician Ltd., your local Abbotsford accountant.
              </p>
              <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
                <Link to="/contact">
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                    <Mail className="mr-2 h-5 w-5" /> Contact Us
                  </Button>
                </Link>
                <a href="tel:778-548-3006">
                  <Button size="lg" variant="outline">
                    <Phone className="mr-2 h-5 w-5" /> Call 778-548-3006
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Faq;