import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Calculator, FileText, Users, Briefcase, Star, Clock, ArrowRight, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
const Home = () => {
  const navigate = useNavigate();
  const handleBookConsultation = () => {
    navigate('/online-booking');
  };
  const services = [{
    icon: <Calculator className="h-8 w-8" />,
    title: "Bookkeeping Services",
    description: "Keep your finances accurate and organized with our professional bookkeeping services in Abbotsford."
  }, {
    icon: <FileText className="h-8 w-8" />,
    title: "Accounting & Tax Services",
    description: "Expert personal and corporate tax filing to maximize your returns and ensure CRA compliance."
  }, {
    icon: <Users className="h-8 w-8" />,
    title: "Payroll Services",
    description: "Reliable payroll processing, including T4/T5 filing, for Abbotsford small businesses."
  }, {
    icon: <Briefcase className="h-8 w-8" />,
    title: "Business Advisory",
    description: "Strategic advice on business registration, financial planning, and growth."
  }];
  const testimonials = [{
    name: "Gurvinder Khabra",
    time: "6 months ago",
    quote: "Excellent Accounting & Financial Services! ... His expertise, professionalism, and dedication made a complex process smooth and stress-free.",
    rating: 5
  }, {
    name: "Piyushsinh Rajput",
    time: "5 months ago",
    quote: "Fast, efficient, and stress-free tax filing! Gopinath handled everything professionally and explained all the details clearly.",
    rating: 5
  }];
  return <>
      <Helmet>
        <title>Accountant in Abbotsford, BC | Bookkeeping & Tax Services | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="Top-rated accountant in Abbotsford, BC offering expert bookkeeping, tax preparation, payroll, and CRA audit support for small businesses and individuals. CPB Canada certified." />
        <link rel="canonical" href="https://gopiaccountant.com/" />
        <meta property="og:title" content="Accountant in Abbotsford, BC | Bookkeeping & Tax Services | Gopi The Accounting Technician Ltd" />
        <meta property="og:description" content="Top-rated accountant in Abbotsford, BC offering expert bookkeeping, tax preparation, payroll, and CRA audit support for small businesses and individuals. CPB Canada certified." />
        <meta name="twitter:title" content="Accountant in Abbotsford, BC | Bookkeeping & Tax Services | Gopi The Accounting Technician Ltd" />
        <meta name="twitter:description" content="Top-rated accountant in Abbotsford, BC offering expert bookkeeping, tax preparation, payroll, and CRA audit support for small businesses and individuals. CPB Canada certified." />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-20"></div>
          <div className="absolute inset-0">
            <div className="absolute top-10 left-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
            <div className="absolute top-40 right-10 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{
            opacity: 0,
            y: -50
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8
          }} className="space-y-6">
              <h2 className="text-xl md:text-3xl font-bold text-white tracking-wide">Gopi - The Accounting Technician Ltd.</h2>
              <p className="font-semibold text-yellow-300 text-lg tracking-wider">From Chaos to Clarity, Cleverly Sorted.</p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Professional Accounting & Bookkeeping Services in Abbotsford, BC
              </h1>
              <p className="text-lg md:text-xl text-blue-100 max-w-3xl mx-auto">Accountant & Certified  Bookkeeper — personalized services for small businesses and individuals.</p>

              <div className="pt-4">
                <Button onClick={handleBookConsultation} size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl shadow-2xl hover:shadow-yellow-500/25 transition-all duration-300 hover:scale-105">
                  Book a Free Consultation
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>

              <div className="flex justify-center items-center space-x-8 pt-8">
                <motion.div initial={{
                opacity: 0,
                scale: 0.8
              }} animate={{
                opacity: 1,
                scale: 1
              }} transition={{
                duration: 0.5,
                delay: 0.4
              }} className="flex flex-col items-center space-y-2">
                  <div className="w-20 h-20 bg-white rounded-lg flex items-center justify-center p-2 shadow-lg">
                    <img loading="lazy" alt="CPB Canada certification logo for Abbotsford bookkeeper" className="max-w-full max-h-full object-contain" src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/ea2371cba95697d801d8c5b991ede8ac.png" />
                  </div>
                  <span className="text-sm font-medium">QuickBooks ProAdvisor</span>
                </motion.div>
                <motion.div initial={{
                opacity: 0,
                scale: 0.8
              }} animate={{
                opacity: 1,
                scale: 1
              }} transition={{
                duration: 0.5,
                delay: 0.6
              }} className="flex flex-col items-center space-y-2">
                  <div className="w-20 h-20 bg-white rounded-lg flex items-center justify-center p-2 shadow-lg">
                    <img loading="lazy" alt="QuickBooks ProAdvisor logo for Abbotsford accounting services" className="max-w-full max-h-full object-contain" src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/ea3572f7ee7ebdbeec8eeca13c34c129.png" />
                  </div>
                  <span className="text-sm font-medium">CPB Canada</span>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} viewport={{
            once: true
          }} className="text-center mb-12 md:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Our Core Services
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Gopi - The Accounting Technician Ltd. offers a full suite of financial services designed to help your Abbotsford business thrive.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {services.map((service, index) => <motion.div key={service.title} initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.6,
              delay: index * 0.1
            }} viewport={{
              once: true
            }} className="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift border border-gray-100 flex flex-col">
                  <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-16 h-16 rounded-xl flex items-center justify-center text-white mb-6 shadow-lg">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-4 flex-grow">{service.description}</p>
                  <Link to="/services">
                    <Button variant="link" className="text-blue-600 font-semibold p-0 self-start">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </motion.div>)}
            </div>
          </div>
        </section>
        
        <section className="py-16 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
             <div className="text-center mb-12 md:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">Real reviews from business owners we've helped.</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {testimonials.map((testimonial, index) => <motion.div key={index} initial={{
              opacity: 0,
              y: 50
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5,
              delay: index * 0.1
            }} viewport={{
              once: true
            }}>
                  <Card className="bg-white p-6 rounded-2xl shadow-lg flex flex-col h-full hover:shadow-xl transition-shadow duration-300">
                    <CardContent className="p-0 flex flex-col h-full">
                      <div className="flex items-center mb-4">
                        <div className="flex-shrink-0 mr-4">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white flex items-center justify-center text-xl font-bold">
                            {testimonial.name.charAt(0)}
                          </div>
                        </div>
                        <div className="flex-grow">
                          <p className="font-bold text-gray-900">{testimonial.name}</p>
                          <p className="text-sm text-gray-500">{testimonial.time}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1 text-yellow-500 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => <Star key={i} className="h-5 w-5 fill-current" />)}
                      </div>
                      <p className="text-gray-700 italic flex-grow">"{testimonial.quote}"</p>
                    </CardContent>
                  </Card>
                </motion.div>)}
            </div>
            <div className="text-center mt-12">
              <Link to="/testimonials">
                  <Button variant="outline">
                    Read More Testimonials <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Tax Tips for Self-Employed in BC</h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-12">
              Stay ahead with our latest insights. Here's a sample from our blog.
            </p>
            <div className="max-w-4xl mx-auto text-left bg-gray-50 p-8 md:p-10 rounded-2xl shadow-lg">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Navigating Self-Employment Taxes</h3>
                <p className="text-gray-700 mb-4">
                  Being self-employed in British Columbia offers freedom, but it also comes with unique tax responsibilities. Unlike traditional employees, you are responsible for remitting your own income tax, as well as CPP contributions. A key to success is setting aside a portion of every payment you receive—typically 25-30%—to cover these obligations.
                </p>
                 <p className="text-gray-700 mb-6">
                  Furthermore, diligently tracking all your business expenses is crucial. From home office costs and vehicle mileage to software subscriptions and professional development, every eligible expense reduces your taxable income, lowering your tax bill.
                </p>
                <Link to="/blog">
                    <Button>
                        Read More on Our Blog <BookOpen className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} viewport={{
            once: true
          }} className="space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready for stress-free accounting?
              </h2>
              <Button onClick={handleBookConsultation} size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                Book a Free Consultation
                <Clock className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>;
};
export default Home;
<Helmet>
  <script type="application/ld+json">
    {`
    {
      "@context": "https://schema.org",
      "@type": "AccountingService",
      "name": "Gopi - The Accounting Technician Ltd.",
      "url": "https://www.gopiaccountant.com",
      "logo": "https://www.gopiaccountant.com/logo.png",
      "telephone": "+1-778-548-3006",
      "email": "accounting@gopiaccountant.com",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Abbotsford, British Columbia",
        "addressLocality": "Abbotsford",
        "addressRegion": "BC",
        "postalCode": "V2S",
        "addressCountry": "CA"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": "49.050",
        "longitude": "-122.316"
      },
      "description": "Top-rated Abbotsford accountant providing bookkeeping, tax filing, payroll, and business advisory services in Fraser Valley.",
      "sameAs": [
        "https://www.facebook.com/p/Gopi-The-Accounting-Technician-61560312008221/"
      ]
    }
    `}
  </script>
</Helmet>