import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, User, Send, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleBookConsultation = () => {
    navigate('/online-booking');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { error } = await supabase.from('contact_messages').insert([
      {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
        subject: 'Contact Form Submission',
      },
    ]);

    setIsSubmitting(false);

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Uh oh! Something went wrong.',
        description: 'There was a problem sending your message. Please try again.',
      });
    } else {
      toast({
        title: 'Message Sent!',
        description: "We've received your message and will get back to you soon.",
      });
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: '',
      });
    }
  };

  const contactInfo = [
    {
      icon: <MapPin className="h-8 w-8 text-white" />,
      title: 'Our Office',
      details: 'Abbotsford, British Columbia',
    },
    {
      icon: <Mail className="h-8 w-8 text-white" />,
      title: 'Email Us',
      details: 'accounting@gopiaccountant.com',
      href: 'mailto:accounting@gopiaccountant.com',
    },
    {
      icon: <Phone className="h-8 w-8 text-white" />,
      title: 'Call Us',
      details: '+1 (778) 548-3006',
      href: 'tel:+17785483006',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Contact Our Abbotsford Accounting Firm | Gopi The Accounting Technician Ltd</title>
        <meta name="description" content="Contact our Abbotsford accounting firm for bookkeeping, CRA audit support, and tax services. Call Gopi The Accounting Technician Ltd at 778-548-3006." />
      </Helmet>
      <div className="bg-gray-50">
        <div className="relative bg-gradient-to-br from-blue-600 to-indigo-700 py-20 md:py-24 text-white text-center">
          <div className="container mx-auto px-4">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight"
            >
              Contact Gopi - The Accounting Technician Ltd.
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-4 text-lg md:text-xl max-w-3xl mx-auto text-blue-100"
            >
              We're ready to help you achieve financial clarity. Reach out today.
            </motion.p>
          </div>
        </div>
        
        <div className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
              
              <div className="space-y-12">
                <div>
                   <h2 className="text-3xl font-bold text-gray-800 mb-6">Contact Information</h2>
                  <div className="space-y-6">
                    {contactInfo.map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -30 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: index * 0.15 }}
                        className="flex items-center space-x-4"
                      >
                        <div className="bg-blue-500 rounded-full p-4 shadow-lg">
                          {item.icon}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">{item.title}</h3>
                          {item.href ? (
                            <a href={item.href} className="text-gray-600 hover:text-blue-600 transition-colors text-lg">
                              {item.details}
                            </a>
                          ) : (
                            <p className="text-gray-600 text-lg">{item.details}</p>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-gray-800 mb-6">Find Our Office</h2>
                  <div className="rounded-lg overflow-hidden shadow-2xl aspect-w-16 aspect-h-9">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d83636.03353494297!2d-122.3912952495817!3d49.05345025983792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548435c1a842f2a3%3A0x2ff253b2a8435a4b!2sAbbotsford%2C%20BC!5e0!3m2!1sen!2sca!4v1671234567890!5m2!1sen!2sca"
                      className="w-full h-full border-0"
                      allowFullScreen=""
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Google Map of Abbotsford Office"
                    ></iframe>
                  </div>
                </div>
              </div>

              <div className="bg-white p-8 md:p-12 rounded-2xl shadow-xl">
                <h2 className="text-3xl font-bold text-center text-gray-800 mb-2">Send Us a Message</h2>
                <p className="text-center text-gray-500 mb-8">Fill out the form below and we'll get back to you shortly.</p>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input type="tel" name="phone" placeholder="Phone" value={formData.phone} onChange={handleChange} className="pl-10" />
                  </div>
                  <div className="relative">
                    <Textarea name="message" placeholder="Message" value={formData.message} onChange={handleChange} required rows={5} />
                  </div>
                  <div className="text-center pt-2">
                    <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? 'Sending...' : 'Send Message'}
                      {!isSubmitting && <Send className="ml-2 h-5 w-5" />}
                    </Button>
                  </div>
                </form>
                 <div className="text-center mt-8">
                  <p className="text-gray-600 mb-4">Or, schedule a meeting directly:</p>
                  <Button onClick={handleBookConsultation} size="lg" variant="outline" className="w-full">
                     <Briefcase className="mr-2 h-5 w-5" /> Book a Free Consultation
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;