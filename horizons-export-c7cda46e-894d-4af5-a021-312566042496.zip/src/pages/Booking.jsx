import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, Clock, User, Mail, Phone, MessageSquare, Briefcase, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Booking = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: 'Bookkeeping',
    preferred_date: '',
    preferred_time: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeSlots, setTimeSlots] = useState([]);

  useEffect(() => {
    if (formData.preferred_date) {
      const day = new Date(formData.preferred_date).getUTCDay();
      let slots = [];
      
      // Monday to Friday (1-5)
      if (day >= 1 && day <= 5) {
        slots.push("08:30 AM");
        for (let i = 9; i < 19; i++) { // 9 AM to 6 PM (18:00)
          const hour = i % 12 === 0 ? 12 : i % 12;
          const ampm = i < 12 ? 'AM' : 'PM';
          slots.push(`${String(hour).padStart(2, '0')}:00 ${ampm}`);
        }
      } 
      // Saturday (6)
      else if (day === 6) {
        for (let i = 9; i < 14; i++) { // 9 AM to 1 PM (13:00)
          const hour = i % 12 === 0 ? 12 : i % 12;
          const ampm = i < 12 ? 'AM' : 'PM';
          slots.push(`${String(hour).padStart(2, '0')}:00 ${ampm}`);
        }
      }
      // Sunday is day 0 - no slots
      setTimeSlots(slots);
      setFormData(prev => ({ ...prev, preferred_time: slots.length > 0 ? slots[0] : '' }));
    } else {
      setTimeSlots([]);
      setFormData(prev => ({ ...prev, preferred_time: '' }));
    }
  }, [formData.preferred_date]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (!formData.preferred_time) {
      toast({
        variant: 'destructive',
        title: 'No time selected',
        description: 'Please select a date with available time slots.',
      });
      setIsSubmitting(false);
      return;
    }

    const { data: appointmentData, error: insertError } = await supabase
      .from('appointments')
      .insert([
        {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          service: formData.service,
          preferred_date: formData.preferred_date,
          preferred_time: formData.preferred_time,
          message: formData.message,
        },
      ])
      .select()
      .single();

    if (insertError) {
      setIsSubmitting(false);
      toast({
        variant: 'destructive',
        title: 'Uh oh! Something went wrong.',
        description: 'There was a problem with your request. Please try again.',
      });
      return;
    }

    try {
      const { error: functionError } = await supabase.functions.invoke('send-appointment-email', {
        body: JSON.stringify({ appointment: appointmentData }),
      });

      if (functionError) {
        throw functionError;
      }

      toast({
        title: 'Consultation Requested!',
        description: "We've received your request and will be in touch shortly.",
      });
      setFormData({
        name: '',
        email: '',
        phone: '',
        service: 'Bookkeeping',
        preferred_date: '',
        preferred_time: '',
        message: '',
      });
    } catch (emailError) {
      console.error('Failed to send notification email:', emailError);
      toast({
        variant: 'destructive',
        title: 'Request Submitted, But...',
        description: 'Your request was saved, but we failed to send an email notification. We will still get in touch.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Book a Free Consultation | Gopi The Accounting Technician Ltd.</title>
        <meta name="description" content="Schedule your free consultation for bookkeeping, tax, and accounting services in Abbotsford, BC. Book online today with Gopi The Accounting Technician Ltd." />
      </Helmet>
      <div className="bg-gradient-to-b from-gray-50 to-blue-100 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4 tracking-tight">
              Book Your Free Consultation
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Take the first step towards financial clarity. Fill out the form below to schedule a free, no-obligation consultation.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="md:grid md:grid-cols-2">
              <div className="p-8 md:p-12">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Details</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input type="text" name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input type="email" name="email" placeholder="Email Address" value={formData.email} onChange={handleChange} required className="pl-10" />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input type="tel" name="phone" placeholder="Phone Number" value={formData.phone} onChange={handleChange} className="pl-10" />
                  </div>

                  <div className="space-y-2">
                    <label className="font-semibold text-gray-700 flex items-center">
                      <Briefcase className="h-5 w-5 mr-2 text-gray-400" />
                      Service of Interest
                    </label>
                    <select name="service" value={formData.service} onChange={handleChange} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                      <option>Bookkeeping Services</option>
                      <option>Accounting & Tax Services</option>
                      <option>Payroll Services</option>
                      <option>Business Advisory</option>
                      <option>General Inquiry</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="relative">
                       <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                       <Input type="date" name="preferred_date" value={formData.preferred_date} onChange={handleChange} required className="pl-10" min={new Date().toISOString().split("T")[0]} />
                    </div>
                    <div className="relative">
                       <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                       <select name="preferred_time" value={formData.preferred_time} onChange={handleChange} required={timeSlots.length > 0} disabled={timeSlots.length === 0} className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition disabled:bg-gray-100">
                          {timeSlots.length > 0 ? (
                           timeSlots.map(slot => <option key={slot} value={slot}>{slot}</option>)
                         ) : (
                           <option>Select a date first</option>
                         )}
                       </select>
                    </div>
                  </div>

                  <div className="relative">
                    <MessageSquare className="absolute left-3 top-4 h-5 w-5 text-gray-400" />
                    <Textarea name="message" placeholder="Tell us a bit about your needs (Optional)" value={formData.message} onChange={handleChange} className="pl-10" />
                  </div>

                  <Button type="submit" className="w-full text-lg font-semibold" disabled={isSubmitting}>
                    {isSubmitting ? 'Requesting...' : 'Request Consultation'}
                    {!isSubmitting && <ArrowRight className="ml-2 h-5 w-5" />}
                  </Button>
                </form>
              </div>
              <div className="hidden md:block bg-gradient-to-br from-blue-500 to-indigo-600 p-12 text-white">
                <div className="flex flex-col justify-center h-full">
                  <h3 className="text-3xl font-bold mb-4">What to Expect</h3>
                  <ul className="space-y-4 text-lg">
                    <li className="flex items-start">
                      <span className="bg-white/20 rounded-full p-1 mr-3 mt-1 flex-shrink-0">
                        <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                      </span>
                      <span>A friendly conversation about your business goals.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-white/20 rounded-full p-1 mr-3 mt-1 flex-shrink-0">
                        <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                      </span>
                      <span>A clear overview of how we can help.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-white/20 rounded-full p-1 mr-3 mt-1 flex-shrink-0">
                        <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                      </span>
                      <span>Transparent pricing and service options.</span>
                    </li>
                  </ul>
                  <div className="mt-10 pt-8 border-t border-white/20">
                    <p className="text-sm italic">"Your path to financial clarity starts here."</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Booking;