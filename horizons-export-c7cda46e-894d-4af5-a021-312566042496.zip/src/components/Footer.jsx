
import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { FaFacebook } from 'react-icons/fa';

const Footer = () => {
  const navigate = useNavigate();

  const handleBookConsultation = () => {
    navigate('/online-booking');
  };

  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: <FaFacebook />, href: "https://www.facebook.com/profile.php?id=61560312008221", name: "Facebook" },
  ];

  return (
    <footer className="bg-gray-800 text-gray-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
             <div className="flex items-center space-x-2">
               <img 
                src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/5d922173b8dedc5f1f1b9286b8905df3.png" 
                alt="Gopi The Accounting Technician Ltd. Logo" 
                className="h-24 w-auto"
              />
            </div>
            <p className="text-sm">
              From Chaos to Clarity, Cleverly Sorted. Your trusted partner for accounting in Abbotsford.
            </p>
            <div className="flex space-x-4 pt-2">
              {socialLinks.map(social => (
                <a key={social.name} href={social.href} target="_blank" rel="noopener noreferrer" aria-label={social.name} className="text-gray-400 hover:text-blue-400 transition-colors text-2xl">
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold text-white block mb-4">Quick Links</span>
            <ul className="space-y-2">
              <li><Link to="/" className="hover:text-blue-400 transition-colors">Home</Link></li>
              <li><Link to="/about" className="hover:text-blue-400 transition-colors">About</Link></li>
              <li><Link to="/services" className="hover:text-blue-400 transition-colors">Services</Link></li>
              <li><Link to="/tax-documents" className="hover:text-blue-400 transition-colors">Tax Documents</Link></li>
              <li><Link to="/faq" className="hover:text-blue-400 transition-colors">FAQ</Link></li>
              <li><Link to="/testimonials" className="hover:text-blue-400 transition-colors">Testimonials</Link></li>
              <li><Link to="/blog" className="hover:text-blue-400 transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="hover:text-blue-400 transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <span className="text-lg font-semibold text-white block mb-4">Contact Info</span>
            <p className="text-white font-bold mb-2">Gopi - The Accounting Technician Ltd.</p>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-blue-400 flex-shrink-0" />
                <a href="tel:+17785483006" className="hover:text-blue-400 transition-colors">+1 (778) 548-3006</a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-blue-400 flex-shrink-0" />
                 <a href="mailto:accounting@gopiaccountant.com" className="hover:text-blue-400 transition-colors">accounting@gopiaccountant.com</a>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin className="h-4 w-4 text-blue-400 flex-shrink-0 mt-1" />
                <span>Abbotsford, BC</span>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <span className="text-lg font-semibold text-white block mb-4">Get Started</span>
            <p className="text-sm">Ready to bring clarity to your finances?</p>
            <Button
              onClick={handleBookConsultation}
              className="w-full mt-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
            >
              Book a Free Consultation
            </Button>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 text-center text-sm">
          <p>&copy; {currentYear} Gopi - The Accounting Technician Ltd. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
