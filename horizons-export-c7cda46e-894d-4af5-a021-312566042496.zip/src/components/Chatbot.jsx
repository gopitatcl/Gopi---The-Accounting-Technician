import React, { useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { detailedInfo, menuItems, checklistItems, checklistTypeNames } from '@/components/chatbot/chatbotConstants';
import { 
  addMonthsSafe, 
  fmt, 
  parsePotentialDate, 
  corporateDeadlineReply,
  endOfMonth,
  gstHstDueDate,
  pstDueDate
} from '@/components/chatbot/chatbotUtils';

const Chatbot = () => {
  const chatbotRef = useRef(null);
  const isInitialized = useRef(false);

  useEffect(() => {
    if (isInitialized.current) return;
    isInitialized.current = true;

    const initChatbot = () => {
      const root = chatbotRef.current;
      if (!root) return;
      root.innerHTML = '';

      const styles = document.createElement('style');
      styles.textContent = `
        .gopi-chat-fab{position:fixed;right:20px;bottom:20px;background:#2563eb;color:#fff;width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 20px rgba(0,0,0,.2);cursor:pointer;z-index:999999; outline:none;border:none}
        .gopi-chat-fab.gopi-pulse{animation:gopi-pulse 2s infinite}
        .gopi-badge{position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;font-size:10px;line-height:1;padding:4px 6px;border-radius:999px;box-shadow:0 2px 6px rgba(0,0,0,.2)}
        @keyframes gopi-pulse {0%{box-shadow:0 0 0 0 rgba(37,99,235,.6)}70%{box-shadow:0 0 0 16px rgba(37,99,235,0)}100%{box-shadow:0 0 0 0 rgba(37,99,235,0)}}
        .gopi-teaser{position:fixed;right:84px;bottom:28px;max-width:240px;background:#111827;color:#fff;padding:10px 12px;border-radius:12px;box-shadow:0 10px 20px rgba(0,0,0,.2);font-size:13px;z-index:999999;display:none}
        .gopi-teaser:after{content:"";position:absolute;right:-6px;bottom:14px;border-width:6px;border-style:solid;border-color:transparent transparent transparent #111827}
        .gopi-chat-wrap{position:fixed;right:20px;bottom:86px;width:360px;max-width:92vw;height:520px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 20px 40px rgba(0,0,0,.2);display:none;flex-direction:column;overflow:hidden;z-index:999999;}
        .gopi-chat-header{display:flex;align-items:center;justify-content:space-between;background:#2563eb;color:#fff;padding:10px 12px}
        .gopi-chat-title{display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px;line-height:1.2}
        .gopi-chat-title img{width:28px;height:28px;border-radius:50%;background:#fff;border:1px solid rgba(255,255,255,.6);object-fit:cover}
        .gopi-chat-actions{display:flex;gap:8px}
        .gopi-chat-btn{background:rgba(255,255,255,.18);color:#fff;border:1px solid rgba(255,255,255,.35);border-radius:8px;padding:6px 10px;font-size:12px;cursor:pointer}
        .gopi-chat-close{background:transparent;border:none;color:#fff;cursor:pointer;font-size:16px}
        .gopi-chat-body{flex:1;background:#f8fafc;padding:10px;overflow-y:auto}
        .gopi-section{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:12px;margin-bottom:10px}
        .gopi-menu{display:grid;grid-template-columns:1fr;gap:8px}
        .gopi-menu button{display:flex;align-items:center;gap:8px;border:1px solid #e5e7eb;background:#f9fafb;border-radius:10px;padding:10px;text-align:left;cursor:pointer}
        .gopi-menu button:hover{background:#eef2ff;border-color:#c7d2fe}
        .gopi-kicker{font-size:12px;color:#6b7280;margin-top:6px}
        .gopi-msg{max-width:100%;margin:8px 0;padding:10px 12px;border-radius:10px;font-size:14px;line-height:1.35}
        .gopi-bot{background:#fff;border:1px solid #e5e7eb;color:#111827}
        .gopi-user{background:#2563eb;color:#fff;margin-left:auto}
        .gopi-typing{font-size:12px;color:#6b7280;margin:6px 0}
        .gopi-chat-input{border-top:1px solid #e5e7eb;background:#fff;padding:8px}
        .gopi-input-row{display:flex;gap:8px}
        .gopi-input{flex:1;border:1px solid #d1d5db;border-radius:8px;padding:8px 10px;font-size:14px}
        .gopi-send{background:#2563eb;color:#fff;border:none;border-radius:8px;padding:8px 12px;font-size:14px;cursor:pointer}
        .gopi-fineprint{font-size:11px;color:#6b7280;margin-top:6px}
        .gopi-list{margin:8px 0;padding-left:0;list-style:none}
        .gopi-list li{margin:4px 0;padding-left:16px;position:relative;font-size:14px;line-height:1.4}
        .gopi-list li:before{content:"•";color:#2563eb;font-weight:bold;position:absolute;left:0}
        .gopi-sublist{margin:6px 0 0 16px;padding-left:0;list-style:none}
        .gopi-sublist li{margin:3px 0;padding-left:16px;font-size:13px;color:#374151}
        .gopi-sublist li:before{content:"◦";color:#6b7280}
        .gopi-highlight{color:#2563eb;font-weight:600}
        .gopi-cta{background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:8px;margin:8px 0;font-size:13px;color:#0369a1}
        .gopi-checklist-menu{display:grid;grid-template-columns:1fr;gap:6px;margin:8px 0}
        .gopi-checklist-menu button{border:1px solid #d1d5db;background:#f9fafb;border-radius:8px;padding:8px 10px;text-align:left;cursor:pointer;font-size:13px}
        .gopi-checklist-menu button:hover{background:#eef2ff;border-color:#c7d2fe}
        .gopi-download-link{display:inline-block;background:#2563eb;color:#fff;padding:8px 16px;border-radius:8px;text-decoration:none;margin:8px 0;font-weight:600}
        .gopi-download-link:hover{background:#1d4ed8}
        @media (max-height:680px){.gopi-chat-wrap{height:74vh}}
      `;
      document.head.appendChild(styles);

      const fab = document.createElement('button');
      fab.className = 'gopi-chat-fab gopi-pulse'; fab.setAttribute('aria-label', 'Open chat'); fab.innerHTML = '💬';
      const badge = document.createElement('span'); badge.className = 'gopi-badge'; badge.textContent = '1';
      fab.appendChild(badge);

      const teaser = document.createElement('div');
      teaser.className = 'gopi-teaser'; teaser.textContent = 'Hi! Need help with deadlines or TFSA/RRSP/FHSA? Click here.';

      const wrap = document.createElement('div'); wrap.className = 'gopi-chat-wrap';
      const header = document.createElement('div'); header.className = 'gopi-chat-header';
      header.innerHTML = `
        <div class="gopi-chat-title">
          <img src="https://horizons-cdn.hostinger.com/c7cda46e-894d-4af5-a021-312566042496/5d922173b8dedc5f1f1b9286b8905df3.png" alt="Gopi Logo">
          <div>Gopi – The Accounting Technician Ltd, Abbotsford BC</div>
        </div>
        <div class="gopi-chat-actions">
          <button class="gopi-chat-btn" id="gopi-menu-btn">Menu</button>
          <button class="gopi-chat-close" title="Close">✕</button>
        </div>
      `;
      const body = document.createElement('div'); body.className = 'gopi-chat-body';
      const inputBar = document.createElement('div'); inputBar.className = 'gopi-chat-input';
      inputBar.innerHTML = `
        <div class="gopi-input-row">
          <input class="gopi-input" type="text" placeholder="Type your question or pick an option..." />
          <button class="gopi-send">Send</button>
        </div>
        <div class="gopi-fineprint">We use Canadian tax terminology. For personal advice, please book an appointment.</div>
      `;
      wrap.appendChild(header); wrap.appendChild(body); wrap.appendChild(inputBar);

      root.appendChild(fab); root.appendChild(teaser); root.appendChild(wrap);

      const input = inputBar.querySelector('.gopi-input');
      const sendBtn = inputBar.querySelector('.gopi-send');
      const closeBtn = header.querySelector('.gopi-chat-close');
      const menuBtn = header.querySelector('#gopi-menu-btn');

      let isOpen = false, expectingEmailForPDF = false;
      let currentChecklistRequest = null;
      let greetedThisSession = false;

      function greetOnce() {
        if (greetedThisSession) return;
        greetedThisSession = true;
        addMsg('👋 Welcome to Gopi – The Accounting Technician Ltd (Abbotsford, BC). I can help with bookkeeping, tax filing, deadlines, checklists, benefits, and TFSA/FHSA/RRSP.', 'bot');
        addMsg('Type "menu" anytime to see options, or ask me something like "calculate my corporate deadline" or "send me the personal tax checklist".', 'bot');
      }

      function openChat() {
        isOpen = true; wrap.style.display = 'flex'; teaser.style.display = 'none';
        fab.classList.remove('gopi-pulse'); badge.style.display = 'none';
        input.focus(); body.scrollTop = body.scrollHeight;
        localStorage.setItem('gopi_chat_seen', String(Date.now()));
        greetOnce();
      }

      function closeChat() {
        isOpen = false; wrap.style.display = 'none';
        setTimeout(() => { if (!isOpen) showTeaser(); }, 6000);
        setTimeout(() => { if (!isOpen) { fab.classList.add('gopi-pulse'); badge.style.display = 'inline-block'; } }, 8000);
      }

      function showTeaser() { teaser.style.display = 'block'; setTimeout(() => { teaser.style.display = 'none'; }, 6000); }
      function addMsg(text, sender = 'bot') {
        const msg = document.createElement('div'); msg.className = `gopi-msg ${sender === 'user' ? 'gopi-user' : 'gopi-bot'}`;
        msg.textContent = text; body.appendChild(msg); body.scrollTop = body.scrollHeight;
      }
      function addHTMLMsg(html, sender = 'bot') {
        const msg = document.createElement('div'); msg.className = `gopi-msg ${sender === 'user' ? 'gopi-user' : 'gopi-bot'}`;
        msg.innerHTML = html; body.appendChild(msg); body.scrollTop = body.scrollHeight;
      }
      function clearBody() { body.innerHTML = ''; }

      function section(title, contentEl) {
        const s = document.createElement('div'); s.className = 'gopi-section';
        if (title) {
          const h = document.createElement('div'); h.style = "font-weight:600;margin-bottom:8px;color:#1f2937";
          h.textContent = title; s.appendChild(h);
        }
        s.appendChild(contentEl); return s;
      }

      function renderMenu() {
        clearBody();
        const menu = document.createElement('div'); menu.className = 'gopi-menu';
        
        menuItems.forEach(it => {
          const b = document.createElement('button'); b.textContent = it.label; b.dataset.key = it.k;
          b.addEventListener('click', () => handleMenuSelect(it.k, it.label)); menu.appendChild(b);
        });
        const box = section('How can I help you today?', menu);
        const kicker = document.createElement('div'); kicker.className = 'gopi-kicker';
        kicker.textContent = 'Tip: Type a year-end like "Dec 31, 2024" to calculate corporate deadlines.';
        body.appendChild(box); body.appendChild(kicker);
      }

      function renderChecklistMenu() {
        const checklistMenu = document.createElement('div'); checklistMenu.className = 'gopi-checklist-menu';
        
        checklistItems.forEach(it => {
          const b = document.createElement('button'); b.textContent = it.label; b.dataset.key = it.k;
          b.addEventListener('click', () => { addMsg(it.label, 'user'); setTimeout(() => askForEmailPDF(it.k), 300); });
          checklistMenu.appendChild(b);
        });
        addHTMLMsg('<div class="gopi-highlight">📑 Which checklist would you like?</div>', 'bot');
        const msg = document.createElement('div'); msg.className = 'gopi-msg gopi-bot'; msg.appendChild(checklistMenu);
        body.appendChild(msg); body.scrollTop = body.scrollHeight;
      }
      
      function askForEmailPDF(checklistType) {
        const displayName = checklistTypeNames[checklistType] || checklistType;
        addMsg(`📂 I can email you the ${displayName} from Gopi – The Accounting Technician Ltd, Abbotsford BC. Please provide your email address.`, 'bot');
        expectingEmailForPDF = true; currentChecklistRequest = checklistType;
      }

      async function sendChecklistEmail(email, checklistType) {
        try {
          const { error } = await supabase.functions.invoke('send-pdf-email', {
            body: JSON.stringify({ email: email, checklistType: checklistType }),
          });

          if (error) throw error;
          
          const displayName = checklistTypeNames[checklistType] || checklistType;
          addMsg(`✅ Thanks! Your ${displayName} has been emailed from accounting@gopiaccountant.com. Please check your inbox (and spam folder).`, 'bot');
          addMsg(`📞 Questions? Call us at 778-548-3006 or visit gopiaccountant.com`, 'bot');
        } catch (error) {
          console.error("Error sending email:", error);
          addMsg("⚠️ Oops, something went wrong sending the email. Please call us at 778‑548‑3006 to get your PDF.", "bot");
        }
      }

      function handleMenuSelect(key, label) {
        addMsg(label, 'user');
        setTimeout(() => {
          if (key === 'checklists') { renderChecklistMenu(); return; }
          addHTMLMsg(detailedInfo[key], 'bot');
        }, 200);
      }

      function handleTextInput(text) {
        const t = text.trim(); if (!t) return; const lower = t.toLowerCase();
        const greetingPatterns = [/\bhi\b/, /\bhello\b/, /\bhey\b/, /\bhowdy\b/, /\bhiya\b/, /\bgood\s+morning\b/, /\bgood\s+afternoon\b/, /\bgood\s+evening\b/, /\bnamaste\b/, /\bhola\b/];
        if (greetingPatterns.some(rx => rx.test(lower))) { addMsg('👋 Hi there! How can I help today? Type "menu" to see options or ask me about deadlines, checklists, TFSA/FHSA/RRSP, benefits, booking, or contact.', 'bot'); return; }

        if (expectingEmailForPDF) {
          expectingEmailForPDF = false;
          const email = (t.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i) || [])[0];
          if (email) {
            addMsg(`Got it: ${email}. Sending your PDF...`, 'bot');
            sendChecklistEmail(email, currentChecklistRequest); currentChecklistRequest = null;
          } else {
            addMsg(`That doesn't look like an email. Please provide a valid email so we can send the PDF.`, 'bot'); expectingEmailForPDF = true;
          }
          return;
        }
        
        if (/(gst|hst)/i.test(lower)) {
          const freq = (lower.match(/monthly|quarter(?:ly)?|annual(?:ly)?/i) || [])[0] || '';
          const d = parsePotentialDate(t);
          if (freq && d) {
            const due = gstHstDueDate(d, freq);
            addMsg(`✅ GST/HST (${freq.toLowerCase()}) for period end ${fmt(d)} is due ${fmt(due)}.`, 'bot');
            addMsg('Need help filing? Call 778-548-3006 or ask for our checklists.', 'bot');
            return;
          }
          addMsg('For GST/HST, please include frequency and period end, e.g., "GST monthly period end Jul 31, 2025".', 'bot');
          addHTMLMsg(detailedInfo.deadlines, 'bot');
          return;
        }

        if (/\bpst\b/i.test(lower)) {
          const d = parsePotentialDate(t);
          if (d) {
            const due = pstDueDate(d);
            addMsg(`✅ PST for period end ${fmt(d)} is due ${fmt(due)} (last day of the month after).`, 'bot');
            return;
          }
          addMsg('For PST, include the period end date, e.g., "PST period end Jul 31, 2025".', 'bot');
          addHTMLMsg(detailedInfo.deadlines, 'bot');
          return;
        }

        const dateReply = corporateDeadlineReply(t);
        if (dateReply) { addMsg(dateReply, 'bot'); addMsg('Would you like to book a quick consult to plan filings? Call 778-548-3006', 'bot'); return; }

        if (lower.includes('menu')) { renderMenu(); return; }
        if (lower.includes('personal') && lower.includes('checklist')) { askForEmailPDF('personal'); return; }
        if (lower.includes('business') && lower.includes('checklist')) { askForEmailPDF('business'); return; }
        if (lower.includes('self') && lower.includes('checklist')) { askForEmailPDF('self_employed'); return; }
        if (lower.includes('trust') && lower.includes('checklist')) { askForEmailPDF('family_trust'); return; }
        if (lower.includes('non') && lower.includes('checklist')) { askForEmailPDF('non_profit'); return; }
        if (lower.includes('checklist') || lower.includes('document')) { renderChecklistMenu(); return; }
        if (lower.includes('bookkeep')) { addHTMLMsg(detailedInfo.bookkeeping, 'bot'); return; }
        if (lower.includes('personal') || lower.includes('tax filing') || lower.includes('t1')) { addHTMLMsg(detailedInfo.tax_filing, 'bot'); return; }
        if (lower.includes('deadline') || lower.includes('t2') || lower.includes('gst') || lower.includes('hst')) { addHTMLMsg(detailedInfo.deadlines, 'bot'); return; }
        if (lower.includes('benefit') || lower.includes('credit')) { addHTMLMsg(detailedInfo.benefits, 'bot'); return; }
        if (lower.includes('tfsa') || lower.includes('fhsa') || lower.includes('rrsp')) { addHTMLMsg(detailedInfo.savings, 'bot'); return; }
        if (lower.includes('appoint') || lower.includes('book')) { addHTMLMsg(detailedInfo.appointment, 'bot'); return; }
        if (lower.includes('contact') || lower.includes('phone') || lower.includes('email')) { addHTMLMsg(detailedInfo.contact, 'bot'); return; }
        if (lower.includes('pdf')) { renderChecklistMenu(); return; }

        addMsg('Happy to help! Type "menu" to see options or ask me about deadlines, document checklists, TFSA/FHSA/RRSP, benefits, booking, or contact.', 'bot');
      }

      function send() { const val = input.value.trim(); if (!val) return; addMsg(val, 'user'); input.value = ''; setTimeout(() => { handleTextInput(val); }, 400); }
      fab.addEventListener('click', () => { isOpen ? closeChat() : openChat(); });
      teaser.addEventListener('click', openChat);
      closeBtn.addEventListener('click', closeChat);
      menuBtn.addEventListener('click', renderMenu);
      sendBtn.addEventListener('click', send);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { send(); } });

      function firstOpenIfNeeded() {
        const seen = Number(localStorage.getItem('gopi_chat_seen') || 0); const sevenDays = 7 * 24 * 60 * 60 * 1000;
        if (!seen || (Date.now() - seen) > sevenDays) { openChat(); renderMenu(); }
        else { setTimeout(showTeaser, 4500); setTimeout(() => { fab.classList.add('gopi-pulse'); badge.style.display = 'inline-block'; }, 6500); }
      }

      renderMenu(); firstOpenIfNeeded();
    };

    initChatbot();

  }, []);

  return <div ref={chatbotRef} id="gopi-chatbot-root-container"></div>;
};

export default Chatbot;