export const detailedInfo = {
  bookkeeping: `
    <div class="gopi-highlight">📊 Bookkeeping & Accounting Services</div>
    <ul class="gopi-list">
      <li>Bookkeeping and GST/HST filings</li>
      <li>Payroll & T4 preparation</li>
      <li>Corporate tax (T2) & financial statements</li>
      <li>Business registration & compliance</li>
    </ul>
    <div class="gopi-cta">📞 Call 778-548-3006 to discuss your bookkeeping needs</div>
  `,
  tax_filing: `
    <div class="gopi-highlight">🧾 Tax Filing Services</div>
    <ul class="gopi-list">
      <li>Personal Income Tax (T1)</li>
      <li>Self-Employed Tax Filing</li>
      <li>Corporate Tax (T2) & GST/HST Returns</li>
      <li>Trust/Family Trust (T3)</li>
      <li>Non-Profit Filings</li>
    </ul>
    <div class="gopi-cta">Which type do you need help with? Call 778-548-3006</div>
  `,
  deadlines: `
  <div class="gopi-highlight">⏱ Tax Filing Deadlines & Calculators</div>
  <ul class="gopi-list">
    <li><strong>Personal (T1):</strong> April 30</li>
    <li><strong>Self-Employed (T1):</strong> File by June 15 (balance due April 30)</li>
    <li><strong>T4/T5 Slips:</strong> Last day of February</li>
    <li><strong>Corporate (T2):</strong> File within 6 months after year-end</li>
    <li><strong>GST/HST (filing/payment):</strong>
      <ul class="gopi-sublist">
        <li>Monthly: due by the <em>last day</em> of the next month</li>
        <li>Quarterly: due by the <em>last day</em> of the month after the quarter-end</li>
        <li>Annual: due <em>3 months</em> after the period end</li>
      </ul>
    </li>
    <li><strong>PST (BC):</strong> Due date is the <em>last day of the month after</em> your reporting period end (e.g., period ending Jul 31 → due Aug 31)</li>
    <li><strong>Trust (T3):</strong> 90 days after year-end</li>
  </ul>
  <div class="gopi-cta">👉 Calculators:
    <br/>• Corporate: type your year-end (e.g., "Dec 31, 2024")
    <br/>• GST/HST: type "GST monthly period end Jul 31, 2025" (or quarterly/annual)
    <br/>• PST: type "PST period end Jul 31, 2025"
  </div>
`,
  benefits: `
    <div class="gopi-highlight">💰 Government Benefits & Credits</div>
    <ul class="gopi-list">
      <li>GST/HST Credit</li>
      <li>Canada Child Benefit (CCB)</li>
      <li>Disability Tax Credit (DTC)</li>
      <li>Climate Action Incentive (CAI)</li>
      <li>Canada Workers Benefit (CWB)</li>
    </ul>
    <div class="gopi-cta">👉 Eligibility depends on income, residency, and family situation. Book a review for personalized advice.</div>
  `,
  savings: `
    <div class="gopi-highlight">📈 TFSA, FHSA & RRSP Contribution Details</div>
    <ul class="gopi-list">
      <li><strong>TFSA</strong>
        <ul class="gopi-sublist">
          <li>Room = unused + new annual limit – contributions</li>
          <li>Withdrawals restore next year</li>
          <li>Over-contrib penalty: 1%/month</li>
        </ul>
      </li>
      <li><strong>FHSA</strong>
        <ul class="gopi-sublist">
          <li>Annual: $8,000 | Lifetime: $40,000</li>
          <li>Over-contrib penalty: 1%/month</li>
          <li>First-home withdrawals tax-free</li>
        </ul>
      </li>
      <li><strong>RRSP</strong>
        <ul class="gopi-sublist">
          <li>Limit = 18% of prior-year income (max $31,560 in 2024) + unused room</li>
          <li>Over-contrib > $2,000 → 1%/month penalty</li>
        </ul>
      </li>
    </ul>
    <div class="gopi-cta">👉 Call 778-548-3006 for personalized contribution room calculations.</div>
  `,
  appointment: `
    <div class="gopi-highlight">📅 Book an Appointment</div>
    <ul class="gopi-list">
      <li><strong>Website:</strong> gopiaccountant.com</li>
      <li><strong>Phone:</strong> 778‑548‑3006</li>
      <li>We'll confirm docs and next steps</li>
    </ul>
  `,
  contact: `
    <div class="gopi-highlight">📞 Contact Information</div>
    <ul class="gopi-list">
      <li><strong>Business:</strong> Gopi – The Accounting Technician Ltd, Abbotsford, BC</li>
      <li><strong>Phone:</strong> 778‑548‑3006</li>
      <li><strong>Email:</strong> accounting@gopiaccountant.com</li>
      <li><strong>Website:</strong> gopiaccountant.com</li>
    </ul>
  `
};

export const menuItems = [
  { k: 'bookkeeping', label: '1️⃣ Bookkeeping & Accounting Services' },
  { k: 'tax_filing', label: '2️⃣ Tax Filing Services (Personal, Self-employed, Corporate, Trust)' },
  { k: 'checklists', label: '3️⃣ Document Checklists' },
  { k: 'deadlines', label: '4️⃣ Tax Filing Deadlines & Calculator (T2, GST/HST)' },
  { k: 'benefits', label: '5️⃣ Government Benefits & Credits (GST, CCB, DTC, CAI, CWB)' },
  { k: 'savings', label: '6️⃣ TFSA, FHSA & RRSP Contribution Details' },
  { k: 'appointment', label: '7️⃣ Book an Appointment' },
  { k: 'contact', label: '8️⃣ Contact Gopi' }
];

export const checklistItems = [
  { k: 'personal', label: '📄 Personal Tax Checklist' },
  { k: 'business', label: '🏢 Business (Incorporated) Checklist' },
  { k: 'self_employed', label: '💼 Self-Employed Checklist' },
  { k: 'family_trust', label: '🏛️ Family Trust Checklist' },
  { k: 'non_profit', label: '🤝 Non-Profit Checklist' }
];

export const checklistTypeNames = { 
  personal: 'Personal Tax Checklist', 
  business: 'Business Incorporated Checklist', 
  self_employed: 'Self-Employed Checklist', 
  family_trust: 'Family Trust Checklist', 
  non_profit: 'Non-Profit Checklist' 
};