export function addMonthsSafe(date, months) {
  const d = new Date(date.getTime());
  const day = d.getDate();
  d.setMonth(d.getMonth() + months);
  while (d.getDate() < day) {
    d.setDate(d.getDate() - 1);
  }
  return d;
}

export function fmt(d) {
  return d.toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function parsePotentialDate(text) {
  const cleaned = text.replace(/(\d+)(st|nd|rd|th)/gi, '$1').replace(/,/g, '');
  const d = new Date(cleaned);
  return isNaN(d) ? null : d;
}

export function endOfMonth(dt) {
  const d = new Date(dt.getTime());
  d.setMonth(d.getMonth() + 1, 0);
  return d;
}

export function gstHstDueDate(periodEnd, frequency) {
  const f = (frequency || '').toLowerCase();
  if (f.includes('month')) {
    return endOfMonth(addMonthsSafe(periodEnd, 1));
  }
  if (f.includes('quarter')) {
    return endOfMonth(addMonthsSafe(periodEnd, 1));
  }
  return addMonthsSafe(periodEnd, 3);
}

export function pstDueDate(periodEnd) {
  return endOfMonth(addMonthsSafe(periodEnd, 1));
}

export function corporateDeadlineReply(dateStr) {
  const d = parsePotentialDate(dateStr);
  if (!d) return null;
  const filing = addMonthsSafe(d, 6);
  const payment2 = addMonthsSafe(d, 2);
  const payment3 = addMonthsSafe(d, 3);
  return `✅ Based on a year-end of ${fmt(d)}:
  📄 Corporate T2 Filing Deadline: ${fmt(filing)} (6 months after year-end)
  💰 Corporate Tax Payment Deadline: ${fmt(payment2)} (2 months after year-end, or ${fmt(payment3)} if eligible small business)
  ⚠️ Late filing/paying may result in penalties and interest.`;
}